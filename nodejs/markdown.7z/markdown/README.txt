NOTE FROM NOT_A_SEAGULL:

this directory contains the legacy markdown renderer, which is no longer in use. these files are all licensed under AGPL
